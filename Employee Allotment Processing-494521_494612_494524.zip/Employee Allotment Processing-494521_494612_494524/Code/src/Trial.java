
public class Trial {

	
	public static void main(String[] args) {
		String sys = "SYSTEM";

		String m_sys_id=sys.substring(0,2)+Math.round(Math.random()+1111);
		
		System.out.println(m_sys_id);
	
		
	}
}


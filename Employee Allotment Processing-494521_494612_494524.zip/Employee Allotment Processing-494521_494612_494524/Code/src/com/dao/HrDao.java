package com.dao;

public interface HrDao {

	boolean SendJoining(int id);
	public boolean delete (String id);
}
